﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class Role
    {
        /// <summary>
        /// 角色标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 角色描述
        /// </summary>
        public string description { get; set; }

        /// <summary>
        /// 角色名称
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// 角色状态
        /// </summary>
        public int status { get; set; }
    }
}
