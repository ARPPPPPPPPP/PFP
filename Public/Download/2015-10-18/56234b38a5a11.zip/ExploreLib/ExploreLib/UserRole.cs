﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class UserRole
    {
        /// <summary>
        /// 标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 人员标识
        /// </summary>
        public int userId { get; set; }

        /// <summary>
        /// 角色标识
        /// </summary>
        public int roleId { get; set; }
    }
}
