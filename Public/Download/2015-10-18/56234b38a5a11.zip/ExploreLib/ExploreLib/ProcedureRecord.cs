﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class ProcedureRecord
    {
        /// <summary>
        /// 流程记录标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 流程标识
        /// </summary>
        public int procedureId { get; set; }

        /// <summary>
        /// 流程改变内容
        /// </summary>
        public string procedureChange { get; set; }

        /// <summary>
        /// 流程改变人标识
        /// </summary>
        public int changePeopleId { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string other { get; set; }
    }
}
