﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class Team
    {
        /// <summary>
        /// 组id
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 组号
        /// </summary>
        public string teamNum { get; set; }

        /// <summary>
        /// 组长
        /// </summary>
        public string teammer { get; set; }

        /// <summary>
        /// 检查员
        /// </summary>
        public string testor { get; set; }

        /// <summary>
        /// 制图员
        /// </summary>
        public string makeMap { get; set; }
    }
}
