﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class Procedure
    {
        /// <summary>
        /// 流程标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 流程种类
        /// </summary>
        public int procedureType { get; set; }

        /// <summary>
        /// 工程标识
        /// </summary>
        public int projectId { get; set; }

        /// <summary>
        /// 当前流程
        /// </summary>
        public int procedureNumber { get; set; }

        /// <summary>
        /// 流程是否结束
        /// </summary>
        public int isFinished { get; set; }

    }
}
