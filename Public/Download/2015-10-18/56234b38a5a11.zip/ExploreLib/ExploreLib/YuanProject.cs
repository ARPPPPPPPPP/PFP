﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib
{
    [Serializable]
    public class YuanProject
    {

        /// <summary>
        /// 项目编号
        /// </summary>
        public string projectNum { get; set; }

        /// <summary>
        /// 项目名称
        /// </summary>
        public string projectName { get; set; }

        /// <summary>
        /// 发文编号
        /// </summary>
        public string publishId { get; set; }

        /// <summary>
        /// 发文时间
        /// </summary>
        public string publishDate { get; set; }

        /// <summary>
        /// 牵头部门
        /// </summary>
        public string qianDepart { get; set; }

        /// <summary>
        /// 牵头部门编号
        /// </summary>
        public string qianDepartNum { get; set; }

        /// <summary>
        /// 分队
        /// </summary>
        public string fenDui { get; set; }

        /// <summary>
        /// 配合部门
        /// </summary>
        public string peiheDepart { get; set; }

        /// <summary>
        /// 专业
        /// </summary>
        public string major { get; set; }

        /// <summary>
        /// 工程地点
        /// </summary>
        public string site { get; set; }

        /// <summary>
        /// 任务通知日期
        /// </summary>
        public string noticeDate { get; set; }

        /// <summary>
        /// 详细工程地点
        /// </summary>
        public string detailSite { get; set; }

        /// <summary>
        /// 项目状态
        /// </summary>
        public string status { get; set; }

        /// <summary>
        /// 工程类别
        /// </summary>
        public string category { get; set; }

        /// <summary>
        /// 来文编号
        /// </summary>f
        public string comeId { get; set; }

        /// <summary>
        /// 委托单位
        /// </summary>
        public string entrustUnit { get; set; }

        /// <summary>
        /// 联系人
        /// </summary>
        public string owner { get; set; }

        /// <summary>
        /// 手机
        /// </summary>
        public string ownercellphone { get; set; }

        /// <summary>
        /// 固定电话
        /// </summary>
        public string ownerphone { get; set; }

        /// <summary>
        /// 质量评定分数
        /// </summary>
        public string qualityGrade { get; set; }

        /// <summary>
        /// 质量评定时间
        /// </summary>
        public string qualityDate { get; set; }

        /// <summary>
        /// 资料图纸
        /// </summary>
        public string ziliao { get; set; }

        /// <summary>
        /// 报建规格
        /// </summary>
        public string baoSpecification { get; set; }

        /// <summary>
        /// 报建长度
        /// </summary>
        public string buildLength { get; set; }

        /// <summary>
        /// 收费期数
        /// </summary>
        public string shoufeiQishu { get; set; }

        /// <summary>
        /// 收费内容
        /// </summary>
        public string shoufeiConteng { get; set; }

        /// <summary>
        /// 收费金额
        /// </summary>
        public string shoufeiMoney { get; set; }

        /// <summary>
        /// 是否已经收款
        /// </summary>
        public string isShoufei { get; set; }

        /// <summary>
        /// 预收款金额
        /// </summary>
        public string preShouMoney { get; set; }

        /// <summary>
        /// 预收款日期
        /// </summary>
        public string preShouDate { get; set; }

        /// <summary>
        /// 实际收款金额
        /// </summary>
        public string realShouMoney { get; set; }

        /// <summary>
        /// 实际收款日期
        /// </summary>
        public string realShouDate { get; set; }

        /// <summary>
        /// WN_ID编号
        /// </summary>
        public string WN_ID { get; set; }

        /// <summary>
        /// 是否已经开票
        /// </summary>
        public string isKaiPiao { get; set; }


        /// <summary>
        /// 计划开始时间
        /// </summary>
        public string planStartDate { get; set; }

        /// <summary>
        /// 计划结束时间
        /// </summary>
        public string planEndDate { get; set; }

        /// <summary>
        /// 实际开始时间
        /// </summary>
        public string realStartDate { get; set; }

        /// <summary>
        /// 实际结束时间
        /// </summary>
        public string realEndDate { get; set; }

        /// <summary>
        /// 收案时间
        /// </summary>
        public string shouanDate { get; set; }

        /// <summary>
        /// 委托时间
        /// </summary>
        public string entrustDate { get; set; }

        /// <summary>
        /// PR_PrjScale
        /// </summary>
        public string PR_PrjScale { get; set; }

        /// <summary>
        /// PR_GaoXinXiangMu
        /// </summary>
        public string PR_GaoXinXiangMu { get; set; }

        /// <summary>
        /// PR_GaoXinXiangMuName
        /// </summary>
        public string PR_GaoXinXiangMuName { get; set; }

        /// <summary>
        /// 工期性质
        /// </summary>
        public string gongqiProp { get; set; }

        /// <summary>
        /// CL_FXNumber
        /// </summary>
        public string CL_FXNumber { get; set; }


    }
}
