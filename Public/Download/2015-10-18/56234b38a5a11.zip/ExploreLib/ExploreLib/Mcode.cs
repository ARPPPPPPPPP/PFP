﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class Mcode
    {
        /// <summary>
        /// 码表标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 码等级
        /// </summary>
        public int mLevel { get; set; }

        /// <summary>
        /// 码名称
        /// </summary>
        public string mKey { get; set; }

        /// <summary>
        /// 码类型
        /// </summary>
        public string mType { get; set; }

        /// <summary>
        /// 码值
        /// </summary>
        public string mValue { get; set; }

        /// <summary>
        /// 码排序
        /// </summary>
        public int orderNum { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string other { get; set; }
    }
}
