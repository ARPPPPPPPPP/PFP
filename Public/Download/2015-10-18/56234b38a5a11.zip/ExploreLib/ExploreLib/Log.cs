﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{

    [Serializable]
    public class Log
    {
        /// <summary>
        /// 日志id
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 用户id
        /// </summary>
        public int userId { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string userName { get; set; }

        /// <summary>
        /// 登陆ip
        /// </summary>
        public string loginIp { get; set; }

        /// <summary>
        /// 登陆时间
        /// </summary>
        public DateTime loginDate { get; set; }

        /// <summary>
        /// 登陆操作
        /// </summary>
        public string loginEvent { get; set; }
    }


}
