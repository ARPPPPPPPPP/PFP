﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class Group
    {
        /// <summary>
        /// 团体标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 团体名称
        /// </summary>
        public string groupName { get; set; }

        /// <summary>
        /// 成员
        /// </summary>
        public string groupMembers { get; set; }

        /// <summary>
        /// 重点事项
        /// </summary>
        public string groupCare { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string other { get; set; }
    }
}
