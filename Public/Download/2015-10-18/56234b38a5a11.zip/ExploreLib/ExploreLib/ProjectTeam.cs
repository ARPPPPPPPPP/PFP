﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class ProjectTeam
    {
        /// <summary>
        /// 分组标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 工程标识
        /// </summary>
        public int projectId { get; set; }

        /// <summary>
        /// 组号
        /// </summary>
        public string teamNum { get; set; }

        /// <summary>
        /// 组长
        /// </summary>
        public string teammer { get; set; }

        /// <summary>
        /// 实际开始时间
        /// </summary>
        public DateTime realStartDate { get; set; }

        /// <summary>
        /// 实际结束时间
        /// </summary>
        public DateTime realEndDate { get; set; }

        /// <summary>
        /// 队检查
        /// </summary>
        public string groupTest { get; set; }

        /// <summary>
        /// 制图员
        /// </summary>
        public string makeMap { get; set; }

        /// <summary>
        /// 质量
        /// </summary>
        public string quality { get; set; }

        /// <summary>
        /// 实测长度
        /// </summary>
        public double realLength { get; set; }

        /// <summary>
        /// 实测规格
        /// </summary>
        public string realSpecification { get; set; }

        /// <summary>
        /// 组产值信息
        /// </summary>
        public string teamValueList { get; set; }

        /// <summary>
        /// 流程步骤
        /// </summary>
        public int procedureStep { get; set; }
        /// <summary>
        /// 检查员
        /// </summary>
        public string testor { get; set; }

        /// <summary>
        /// 检查意见
        /// </summary>
        public string testOpinion { get; set; }
    }
}
