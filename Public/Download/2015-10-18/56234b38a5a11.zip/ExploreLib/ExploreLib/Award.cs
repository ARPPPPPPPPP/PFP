﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class Award
    {
        /// <summary>
        /// 获奖标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 奖项名称
        /// </summary>
        public string awardName { get; set; }

        /// <summary>
        /// 奖项等级
        /// </summary>
        public string awardDegree { get; set; }

        /// <summary>
        /// 获奖时间
        /// </summary>
        public DateTime awardDate { get; set; }

        /// <summary>
        /// 人员
        /// </summary>
        public string awardMembers { get; set; }

        /// <summary>
        /// 证书扫描件
        /// </summary>
        public Byte[] certificate { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string other { get; set; }

        /// <summary>
        /// 证书名
        /// </summary>
        public string certificateName { get; set; }

        /// <summary>
        /// 证书后缀
        /// </summary>
        public string certificateExtension { get; set; }
    }
}
