﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class RolePermission
    {
        /// <summary>
        /// 标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 角色标识
        /// </summary>
        public int roleId { get; set; }

        /// <summary>
        /// 权限标识
        /// </summary>
        public int permId { get; set; }
    }

}
