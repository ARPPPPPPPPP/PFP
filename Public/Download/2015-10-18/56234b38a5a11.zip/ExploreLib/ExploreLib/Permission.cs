﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class Permission
    {
        /// <summary>
        /// 权限标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 权限名称
        /// </summary>
        public string permName { get; set; }

        /// <summary>
        /// 权限描述
        /// </summary>
        public string descript { get; set; }

        /// <summary>
        /// 权限类型
        /// </summary>
        public string permType { get; set; }

        /// <summary>
        /// 权限值
        /// </summary>
        public string permValue { get; set; }
    }
}
