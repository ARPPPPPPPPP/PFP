﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class ProjectFen
    {
        /// <summary>
        /// 分期标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 工程标识
        /// </summary>
        public int projectId { get; set; }

        /// <summary>
        /// 分期结算工程款
        /// </summary>
        public double fenCost { get; set; }

        /// <summary>
        /// 分期结算时间
        /// </summary>
        public DateTime fenDate { get; set; }
    }
}
