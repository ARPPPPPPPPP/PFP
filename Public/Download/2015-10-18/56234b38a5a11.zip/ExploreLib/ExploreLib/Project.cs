﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class Project
    {
        /// <summary>
        /// 工程标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 工程编号
        /// </summary>
        public string projectNum { get; set; }

        /// <summary>
        /// 项目名称
        /// </summary>
        public string projectName { get; set; }

        /// <summary>
        /// 工程规模
        /// </summary>
        public string projectSize { get; set; }

        /// <summary>
        /// 工程所在省区
        /// </summary>
        public string proviceRegion { get; set; }

        /// <summary>
        /// 工程地点
        /// </summary>
        public string site { get; set; }

        /// <summary>
        /// 所属高新技术专利
        /// </summary>
        public string patent { get; set; }

        /// <summary>
        /// 委托时间
        /// </summary>
        public DateTime entrustDate { get; set; }

        /// <summary>
        /// 项目类型
        /// </summary>
        public string type { get; set; }

        /// <summary>
        /// 工程类别
        /// </summary>
        public string category { get; set; }

        /// <summary>
        /// 项目状态
        /// </summary>
        public string status { get; set; }

        /// <summary>
        /// 发文编号
        /// </summary>
        public string publishId { get; set; }

        /// <summary>
        /// 发文时间
        /// </summary>
        public DateTime publishDate { get; set; }

        /// <summary>
        /// 实测长度
        /// </summary>
        public double realLength { get; set; }

        /// <summary>
        /// 报建规格
        /// </summary>
        public string baoSpecification { get; set; }

        /// <summary>
        /// 实测规格
        /// </summary>
        public string realSpecification { get; set; }

        /// <summary>
        /// 报建长度
        /// </summary>
        public double buildLength { get; set; }

        /// <summary>
        /// 委托单位
        /// </summary>
        public string entrustUnit { get; set; }

        /// <summary>
        /// 业主联系人
        /// </summary>
        public string owner { get; set; }

        /// <summary>
        /// 手机
        /// </summary>
        public string ownercellphone { get; set; }

        /// <summary>
        /// 固定电话
        /// </summary>
        public string ownerphone { get; set; }

        /// <summary>
        /// 红线图
        /// </summary>
        public int redLinemap { get; set; }

        /// <summary>
        /// 审核书
        /// </summary>
        public int verifybook { get; set; }

        /// <summary>
        /// 成果资料
        /// </summary>
        public int achievement { get; set; }

        /// <summary>
        /// 管线种类
        /// </summary>
        public string pipeLineType { get; set; }

        /// <summary>
        /// 收案时间
        /// </summary>
        public DateTime shouanDate { get; set; }

        /// <summary>
        /// 任务通知日期
        /// </summary>
        public DateTime noticeDate { get; set; }

        /// <summary>
        /// 施工员
        /// </summary>
        public string worker { get; set; }

        /// <summary>
        /// 施工员电话
        /// </summary>
        public string workerPhone { get; set; }

        /// <summary>
        /// 预付款
        /// </summary>
        public double prepay { get; set; }

        /// <summary>
        /// 结算工程款
        /// </summary>
        public double settleCost { get; set; }

        /// <summary>
        /// 结算时间
        /// </summary>
        public DateTime settleDate { get; set; }

        /// <summary>
        /// 质量评定等级
        /// </summary>
        public string qualityDegree { get; set; }

        /// <summary>
        /// 质量评定分数
        /// </summary>
        public double qualityGrade { get; set; }

        /// <summary>
        /// 质量评定时间
        /// </summary>
        public DateTime qualityDate { get; set; }

        /// <summary>
        /// 产值
        /// </summary>
        public double outputValue { get; set; }

        /// <summary>
        /// 实际开始时间
        /// </summary>
        public DateTime realStartDate { get; set; }

        /// <summary>
        /// 实际结束时间
        /// </summary>
        public DateTime realEndDate { get; set; }

        /// <summary>
        /// 队审查
        /// </summary>
        public string groupCheck { get; set; }

        /// <summary>
        /// 项目取消时间
        /// </summary>
        public DateTime cancelDate { get; set; }

        /// <summary>
        /// 取消原因
        /// </summary>
        public string cancelReason { get; set; }

        /// <summary>
        /// 任务安排时间
        /// </summary>
        public DateTime arrangeDate { get; set; }

        /// <summary>
        /// 提交检查时间
        /// </summary>
        public DateTime testDate { get; set; }

        /// <summary>
        /// 检查员
        /// </summary>
        public string testor { get; set; }

        /// <summary>
        /// 检查意见
        /// </summary>
        public string testOpinion { get; set; }

        /// <summary>
        /// 提交审查时间
        /// </summary>
        public DateTime checkDate { get; set; }

        /// <summary>
        /// 审查人
        /// </summary>
        public string checkor { get; set; }

        /// <summary>
        /// 结案时间
        /// </summary>
        public DateTime jieanDate { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string other { get; set; }

        /// <summary>
        /// 计划工期
        /// </summary>
        public string planDays { get; set; }

        /// <summary>
        /// 结案人
        /// </summary>
        public string jieanPeople { get; set; }

        /// <summary>
        /// 提交结案时间
        /// </summary>
        public DateTime commitJiean { get; set; }

        /// <summary>
        /// 巡视小组
        /// </summary>
        public string tourTeam { get; set; }

        /// <summary>
        /// 安排巡视小组时间
        /// </summary>
        public DateTime tourTeamTime { get; set; }
    }
}
