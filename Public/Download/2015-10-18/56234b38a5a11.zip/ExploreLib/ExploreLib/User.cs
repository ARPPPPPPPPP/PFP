﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class User
    {
        /// <summary>
        /// 人员标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 人员编号
        /// </summary>
        public string userNum { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string userName { get; set; }

        /// <summary>
        /// 身份证号
        /// </summary>
        public string idCardNum { get; set; }

        /// <summary>
        /// 用工性质
        /// </summary>
        public string quality { get; set; }

        /// <summary>
        /// 入院时间
        /// </summary>
        public DateTime enterDate { get; set; }

        /// <summary>
        /// 毕业院校
        /// </summary>
        public string graduateFrom { get; set; }

        /// <summary>
        /// 专业
        /// </summary>
        public string major { get; set; }

        /// <summary>
        /// 手机
        /// </summary>
        public string telephone { get; set; }

        /// <summary>
        /// 家庭住址
        /// </summary>
        public string address { get; set; }

        /// <summary>
        /// 家庭电话
        /// </summary>
        public string homePhone { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string other { get; set; }

        /// <summary>
        /// 岗位
        /// </summary>
        public string station { get; set; }

        /// <summary>
        /// 班组
        /// </summary>
        public string team { get; set; }

        /// <summary>
        /// 职称
        /// </summary>
        public string profession { get; set; }

        /// <summary>
        /// 学历
        /// </summary>
        public string educationBg { get; set; }

        /// <summary>
        /// 学位
        /// </summary>
        public string degree { get; set; }

        /// <summary>
        /// 注册师
        /// </summary>
        public string registor { get; set; }

        /// <summary>
        /// 政治面貌
        /// </summary>
        public string politicalStatus { get; set; }

        /// <summary>
        /// 账号
        /// </summary>
        public string loginName { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string passwd { get; set; }

    }
}
