﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExploreLib.Entity
{
    [Serializable]
    public class Meeting
    {
        /// <summary>
        /// 会议标识
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// 会议类别
        /// </summary>
        public string meetingType { get; set; }

        /// <summary>
        /// 会议名称
        /// </summary>
        public string meetingName { get; set; }

        /// <summary>
        /// 会议时间
        /// </summary>
        public DateTime meetingDate { get; set; }

        /// <summary>
        /// 会议纪要
        /// </summary>
        public Byte[] meetingOutline { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string other { get; set; }

        /// <summary>
        /// 文件名
        /// </summary>
        public string meetingOutlineName { get; set; }

        /// <summary>
        /// 文件后缀
        /// </summary>
        public string meetingOutlineExtension { get; set; }
    }
}
